import AuthForm from "@/components/AuthForm";

const SignUp = () => <AuthForm type="sign-up" />;

export default SignUp;
